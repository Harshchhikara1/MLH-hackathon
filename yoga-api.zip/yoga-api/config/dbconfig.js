const mysql = require('mysql');
const pool = new mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
});

pool.connect((error) =>{
    if(error)
    {
        console.warn("Unable to connect database, please start your server or check your configuration!");
    }else{
        console.log("Connection established with targetted database!")
    }
});

module.exports = pool;