const pool = require('../../config/dbconfig');

module.exports = {
    getCartItem: (user_id, callBack) => {
        pool.query(`select * from cart where user_id=?`, [user_id], (error, results, fields) => {
            if (error) {
                return callBack(error)
                }
                return callBack(null, results)
            })
    },

    addToCart: (data, callBack) =>{
        pool.query('insert into cart SET ?', data, (error, results, fields) => {
            if(error){
                return callBack(error)
            }
            return callBack(null, results)
            
            })
        },

        deleteCart: (user_id, callBack) =>{
            pool.query('delete from cart where user_id=?', [user_id], (error, results, fields) => {
                if(error){
                    return callBack(error)
            }
            return callBack(null, results)
        })
    }
} 
