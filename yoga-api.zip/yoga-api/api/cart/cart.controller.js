const { getCartItem, addToCart, deleteCart } = require('./cart.service')

module.exports = {
    getCartFromDB: (req, res) => {
        var user_id = req.params.user_id;
        getCartItem(user_id, (error, results) => {
            if(results.length <= 0){
                return res.status(404).json({
                    message: "No item in your cart"
                })
            }
            return res.status(200).json({
                message: "Data Found", results
            })
        })
    },

    addItemToCartDB: (req, res) => {
        const data = req.body;
        addToCart(data, (error, results) =>{
            if (error){
                return res.status(404).json({
                    message: "Item already added in your cart or an error in adding item to cart", error
                })
            }
            return res.status(200).json({
                message: "An item successfully added to cart", results
            })

        })
    },
    
    deleteCartFromDB: (req, res) => {
        var user_id = req.params.user_id;
        deleteCart(user_id, (error, results) => {
            if(error){
                return res.status(404).json({
                    message: "An error in deleting cart item", error
                })
            }
            return res.status(200).json({
                message: "Item deleted successfully from cart", results
            })
        })
    }
}