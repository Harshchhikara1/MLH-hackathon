const router = require("express").Router()
const { route } = require("express/lib/router");
const { getCartFromDB, addItemToCartDB, deleteCartFromDB } = require("./cart.controller")
const { checkToken } = require('../../auth/auth')

router.get("/get-cart/:user_id", checkToken, getCartFromDB);
router.post("/add-to-cart", checkToken, addItemToCartDB);
router.delete("/delete-cart/:user_id", checkToken, deleteCartFromDB);

module.exports = router