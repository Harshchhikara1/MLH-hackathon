const { getOrder, placeOrder } = require('./order.service')

module.exports = {
    getOrderFromDB: (req, res) => {
        var user_id = req.params.user_id;
        getOrder(user_id, (error, results) => {
            if(results.length <= 0){
                return res.status(404).json({
                    message: "No order placed yet"
                })
            }
            return res.status(200).json({
                message: "Data Found", results
            })
        })
    },

    addOrderToDB: (req, res) => {
        const data = req.body;
        placeOrder(data, (error, results) =>{
            if (error){
                return res.status(404).json({
                    message: "An error in placing order", error
                })
            }
            return res.status(200).json({
                message: "Order has been successfully placed", results
            })

        })
    }
}