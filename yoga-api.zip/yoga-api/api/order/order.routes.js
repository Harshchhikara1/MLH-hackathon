const router = require("express").Router()
const { route } = require("express/lib/router");
const { getOrderFromDB, addOrderToDB } = require("./order.controller")
const { checkToken } = require('../../auth/auth')

router.get("/get-order/:user_id", checkToken, getOrderFromDB);
router.post("/place-order", checkToken, addOrderToDB);

module.exports = router