const pool = require('../../config/dbconfig');

module.exports = {
    getOrder: (user_id, callBack) => {
        pool.query(`select * from sales_order where user_id=?`, [user_id], (error, results, fields) => {
            if (error) {
                return callBack(error)
                }
                return callBack(null, results)
            })
    },

    placeOrder: (data, callBack) =>{
        pool.query('insert into sales_order SET ?', data, (error, results, fields) => {
            pool.query('delete from cart where user_id=? and package_id=?', [data.user_id, data.package_id], (error, results, fields) => {
                if(error) error;
            })
            if(error){
                return callBack(error)
            }
            return callBack(null, results)

            })
        
        }
} 
