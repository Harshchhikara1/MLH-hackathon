const router = require("express").Router()
const { route } = require("express/lib/router");
const { loginUserToDB, updatePasswordToDB } = require("./login.controller")

router.post("/user-login", loginUserToDB);
router.post("/forgot-password", updatePasswordToDB);

module.exports = router