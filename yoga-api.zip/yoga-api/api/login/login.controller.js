const { loginUser, forgotPassword } = require('./login.service')
const { genSaltSync, hashSync } = require('bcrypt');
const { sign } = require('jsonwebtoken');
var nodemailer = require('nodemailer');

module.exports = {
    loginUserToDB: (req, res) => {
        const data = req.body;
        loginUser(data.customer_email, (error, results) => {
            if (error){
                return res.status(404).json({
                    message: "Incorrect email id or password", error
                })
            }else{
                const salt = genSaltSync(10);
                data.login_password = hashSync(data.login_password, salt);
                results.login_password = hashSync(results.login_password, salt);
                //console.log(data.login_password)
                //console.log(results.login_password)

                if(data.login_password == results.login_password){
                    results.login_password = undefined
                    const access_token = sign({result: results}, process.env.JWT_KEY, {expiresIn: process.env.JWT_EXP})
                    return res.status(200).json({
                        message: "Successfully loggedin", access_token
            })
        }else{
            return res.status(404).json({
                message: "Incorrect email id or password, please try again"
            })
        }       
    }
        })
    },

    updatePasswordToDB: (req, res) => {
        const data = req.body;
        forgotPassword(data.customer_email, (error, results) => {
            if (results.length <= 0){
                return res.status(404).json({
                    message: "No account found linked with this email id"
                })
            }else{
                var transporter = nodemailer.createTransport({
                    service: process.env.EMAIL_TRANSPORTER,
                    auth: {
                      user: process.env.EMAIL_SENDER,
                      pass: process.env.EMAIL_KEY
                    }
                  });

                  var mailOptions = {
                    from: process.env.EMAIL_SENDER,
                    to: data.customer_email,
                    subject: 'Welcome back to Prana Yoga | Password reset link',
                    text: 'Hello,\n\nWelcome back to Prana Yoga! \n\nPlease click on below mentioned link to reset your password.\n\nThank you,\nTeam Prana Yoga'
                  };

                  transporter.sendMail(mailOptions, (error, info) =>{
                    if (error) {
                      return error;
                    } else {
                        return res.status(200).json({
                                message: "Password reset email sent to your registered email id"
            })
        }
    }) 
   } 
  })
 }
}
