const pool = require('../../config/dbconfig');

module.exports = {
    loginUser: (customer_email, callBack) =>{
        pool.query('select * from user_registration where customer_email = ?', [customer_email], (error, results, fields) => {
            if(error){
                return callBack(error)
            }
            return callBack(null, results[0])
            })
        },

    forgotPassword : (customer_email, callBack) => {
        pool.query('select * from user_registration where customer_email = ?', [customer_email], (error, results, fields) => {
            if(error){
                return callBack(error)
            }

            return callBack(null, results)
            })
        }
    }
    
