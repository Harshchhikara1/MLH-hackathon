const router = require("express").Router()
const { route } = require("express/lib/router");
const { getProductFromDB, getProductByAsanaNameFromDB, getProductByAsanaLevelFromDB, getProductByIdFromDB, getProductImageByProductIdFromDB, getProductVideoByProductIdFromDB } = require("./product.controller")
const { checkToken } = require('../../auth/auth')

router.get("/get-product", checkToken, getProductFromDB);
router.get("/get-product-image/:product_id", checkToken, getProductImageByProductIdFromDB);
router.get("/get-product-video/:product_id", checkToken, getProductVideoByProductIdFromDB);
router.get("/get-product/:id", checkToken, getProductByIdFromDB);
router.post("/get-product/asana-name", checkToken, getProductByAsanaNameFromDB);
router.post("/get-product/asana-level", checkToken, getProductByAsanaLevelFromDB);

module.exports = router