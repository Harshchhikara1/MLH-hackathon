const pool = require('../../config/dbconfig');

module.exports = {
    getProduct: callBack => {
        pool.query(` 
        select * from product`,
            [],
            (error, results, fields) => {
                if (error) {
                    return callBack(error)
                }
                return callBack(null, results)
            })
    },

    getProductById: (id, callBack) => {
        pool.query(` 
        select * from product where id=?`,
            [id],
            (error, results, fields) => {
                if (error) {
                    return callBack(error)
                }
                return callBack(null, results)
            })
    },

    getProductImageByProductId: (product_id, callBack) => {
        pool.query(` 
        select * from product_image where product_id=?`,
            [product_id],
            (error, results, fields) => {
                if (error) {
                    return callBack(error)
                }
                return callBack(null, results)
            })
    },

    getProductVideoByProductId: (product_id, callBack) => {
        pool.query(` 
        select * from product_video where product_id=?`,
            [product_id],
            (error, results, fields) => {
                if (error) {
                    return callBack(error)
                }
                return callBack(null, results)
            })
    },

    getProductByAsanaName: (data, callBack) => {
        pool.query(`
        select * from product where asana_name =?`, data, (error, results, fields) => {
            if (error) {
                return callBack(error)
                }
                return callBack(null, results)
            })
    },

    getProductByAsanaLevel: (data, callBack) => {
        pool.query('select * from product where asana_level =?', data, (error, results, fields) => {
            if (error) {
                return callBack(error)
                }
                return callBack(null, results)
            })
    }

} 
