const { getProduct, getProductById, getProductByAsanaName, getProductByAsanaLevel, getProductImageByProductId, getProductVideoByProductId } = require('./product.service')

module.exports = {
    getProductFromDB: (req, res) => {
        getProduct((error, results) => {
            if(error){
                return res.status(404).json({
                    message: "Data not found"
                })
            }
            return res.status(200).json({
                message: "Data Found", results
            })
        })
    },

    getProductByIdFromDB: (req, res) => {
        const id = req.params.id
        getProductById(id, (error, results) => {
            if(results.length <= 0){
                return res.status(404).json({
                    message: "Data not found"
                })
            }
            return res.status(200).json({
                message: "Data found", results 
            })

        })
    },

    getProductImageByProductIdFromDB: (req, res) => {
        const product_id = req.params.product_id
        getProductImageByProductId(product_id, (error, results) => {
            if(results.length <= 0){
                return res.status(404).json({
                    message: "Data not found"
                })
            }
            return res.status(200).json({
                message: "Data found", results 
            })

        })
    },

    getProductVideoByProductIdFromDB: (req, res) => {
        const product_id = req.params.product_id
        getProductVideoByProductId(product_id, (error, results) => {
            if(results.length <= 0){
                return res.status(404).json({
                    message: "Data not found"
                })
            }
            return res.status(200).json({
                message: "Data found", results 
            })

        })
    },


    getProductByAsanaNameFromDB: (req, res) => {
        const asana_name = req.body.asana_name
        getProductByAsanaName(asana_name, (error, results) => {
            if(results.length <= 0){
                return res.status(404).json({
                    message: "Data not found"
                })
            }
            return res.status(200).json({
                message: "Data found", results
            })

        })
    },

    getProductByAsanaLevelFromDB: (req, res) => {
        const asana_level = req.body.asana_level
        getProductByAsanaLevel(asana_level, (error, results) => {
            if(results.length <= 0){
                return res.status(404).json({
                    message: "Data not found"
                })
            }
            return res.status(200).json({
                message: "Data found", results
            })

        })
    }
}