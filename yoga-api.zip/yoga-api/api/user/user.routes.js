const router = require("express").Router()
const { route } = require("express/lib/router");
const { getUserFromDB, getUserByIdFromDB, getUserByEmailFromDB, getUserByMobileFromDB, postUserToDB, updateUserToDB } = require("./user.controller")
const { checkToken } = require('../../auth/auth')

router.get("/get-user", checkToken, getUserFromDB);
router.get("/get-user/:id", checkToken, getUserByIdFromDB);
router.post("/get-user/email", checkToken, getUserByEmailFromDB);
router.post("/get-user/mobile", checkToken, getUserByMobileFromDB);
router.post("/create-user", postUserToDB);
router.put("/update-user/:id", checkToken, updateUserToDB);

module.exports = router