const pool = require('../../config/dbconfig');

module.exports = {
    getUser: callBack => {
        pool.query(` 
        select * from user_registration`,
            [],
            (error, results, fields) => {
                if (error) {
                    return callBack(error)
                }
                return callBack(null, results)
            })
    },

    getUserById: (id, callBack) => {
        pool.query(` 
        select * from user_registration where id=?`,
            [id],
            (error, results, fields) => {
                if (error) {
                    return callBack(error)
                }
                return callBack(null, results)
            })
    },

    getUserByEmail: (data, callBack) => {
        pool.query(`
        select * from user_registration where customer_email =?`, data, (error, results, fields) => {
            if (error) {
                return callBack(error)
                }
                return callBack(null, results)
            })
    },

    getUserByMobile: (data, callBack) => {
        pool.query('select * from user_registration where customer_mobile =?', data, (error, results, fields) => {
            if (error) {
                return callBack(error)
                }
                return callBack(null, results)
            })
    },

    createUser: (data, callBack) =>{
        pool.query('insert into user_registration SET ?', data, (error, results, fields) => {
            if(error){
                return callBack(error)
            }
            return callBack(null, results)
            
            })
        },

        updateUser: ([data, id], callBack) =>{
            pool.query('update user_registration SET customer_name=?, login_password=? where id=?', [data.customer_name, data.login_password, id], (error, results, fields) => {
                if(error){
                    return callBack(error)
                }
                return callBack(null, results)
                })
            }
    } 
