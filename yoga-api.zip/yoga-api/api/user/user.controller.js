const { getUser, getUserById, getUserByEmail, getUserByMobile, createUser, updateUser, userLogin } = require('./user.service')
const { genSaltSync, hashSync } = require('bcrypt');
var nodemailer = require('nodemailer');

module.exports = {
    getUserFromDB: (req, res) => {
        getUser((error, results) => {
            if(error){
                return res.status(404).json({
                    message: "Data not found"
                })
            }
            return res.status(200).json({
                message: "Data Found", results
            })
        })
    },

    getUserByIdFromDB: (req, res) => {
        const id = req.params.id
        getUserById(id, (error, results) => {
            if(results.length <= 0){
                return res.status(404).json({
                    message: "Data not found"
                })
            }
            return res.status(200).json({
                message: "Data found", results
            })

        })
    },

    getUserByEmailFromDB: (req, res) => {
        const customer_email = req.body.customer_email
        getUserByEmail(customer_email, (error, results) => {
            if(results.length <= 0){
                return res.status(404).json({
                    message: "Data not found"
                })
            }
            return res.status(200).json({
                message: "Data found", results
            })

        })
    },

    getUserByMobileFromDB: (req, res) => {
        const customer_mobile = req.body.customer_mobile
        getUserByMobile(customer_mobile, (error, results) => {
            if(results.length <= 0){
                return res.status(404).json({
                    message: "Data not found"
                })
            }
            return res.status(200).json({
                message: "Data found", results
            })

        })
    },

    postUserToDB: (req, res) => {
        const data = req.body;
        const salt = genSaltSync(10);
        data.login_password = hashSync(data.login_password, salt);        
        createUser(data, (error, results) => {
            if(error){
                return res.status(400).json({
                    message: "Email or mobile already exists", error
                })
            }

            var transporter = nodemailer.createTransport({
                service: process.env.EMAIL_TRANSPORTER,
                auth: {
                  user: process.env.EMAIL_SENDER,
                  pass: process.env.EMAIL_KEY
                }
              });
              
              var mailOptions = {
                from: process.env.EMAIL_SENDER,
                to: data.customer_email,
                subject: 'Welcome to Prana Yoga',
                text: 'Dear '+ data.customer_name + ',\n\nWelcome to Prana Yoga! \n\nPlease login into your account with your registered email id and generated password to explore our way of Yoga world.\n\nThank you,\nTeam Prana Yoga'
              };
              
              transporter.sendMail(mailOptions, (error, info) =>{
                if (error) {
                  return error;
                } else {
                    console.log('Email sent: ' + info.response);
                    return res.status(201).json({
                        message: "User created successfully and confirmation email sent to registered email id", results
                    })
                }
              });
        })
    },

    updateUserToDB: (req, res) => {
        const data = req.body;
        const data1 = req.params.id;
        const salt = genSaltSync(10);
        data.login_password = hashSync(data.login_password, salt);
        updateUser([data, data1], (error, results) => {
            if(error){
                return res.status(400).json({
                    message: "There is an error in updating details, please try again", error
                })
            }
            return res.status(201).json({
                message: "Details updated successfully", results
            })

        })
    }
}