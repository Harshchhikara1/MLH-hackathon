const { getSubscriptionPackage, getSubscriptionPackageById, getSubscriptionPackageByName } = require('./subscription.service')

module.exports = {
    getSubscriptionPackageFromDB: (req, res) => {
        getSubscriptionPackage((error, results) => {
            if(error){
                return res.status(404).json({
                    message: "Data not found"
                })
            }
            return res.status(200).json({
                message: "Data Found", results
            })
        })
    },

    getSubscriptionPackageByIdFromDB: (req, res) => {
        const id = req.params.id
        getSubscriptionPackageById(id, (error, results) => {
            if(results.length <= 0){
                return res.status(404).json({
                    message: "Data not found"
                })
            }
            return res.status(200).json({
                message: "Data found", results 
            })

        })
    },

    getSubscriptionPackageByNameFromDB: (req, res) => {
        const package_name = req.body.package_name
        getSubscriptionPackageByName(package_name, (error, results) => {
            if(results.length <= 0){
                return res.status(404).json({
                    message: "Data not found"
                })
            }
            return res.status(200).json({
                message: "Data found", results
            })

        })
    }
}