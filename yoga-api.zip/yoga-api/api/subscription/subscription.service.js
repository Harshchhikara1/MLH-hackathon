const pool = require('../../config/dbconfig');

module.exports = {
    getSubscriptionPackage: callBack => {
        pool.query(` 
        select * from subscription_package`,
            [],
            (error, results, fields) => {
                if (error) {
                    return callBack(error)
                }
                return callBack(null, results)
            })
    },

    getSubscriptionPackageById: (id, callBack) => {
        pool.query(` 
        select * from subscription_package where id=?`,
            [id],
            (error, results, fields) => {
                if (error) {
                    return callBack(error)
                }
                return callBack(null, results)
            })
    },

    getSubscriptionPackageByName: (package_name, callBack) => {
        pool.query(` 
        select * from subscription_package where package_name=?`,
            [package_name],
            (error, results, fields) => {
                if (error) {
                    return callBack(error)
                }
                return callBack(null, results)
            })
    }
} 
