const router = require("express").Router()
const { route } = require("express/lib/router");
const { getSubscriptionPackageFromDB, getSubscriptionPackageByIdFromDB, getSubscriptionPackageByNameFromDB } = require("./subscription.controller")
const { checkToken } = require('../../auth/auth')

router.get("/get-subscription", checkToken, getSubscriptionPackageFromDB);
router.get("/get-subscription/:id", checkToken, getSubscriptionPackageByIdFromDB);
router.post("/get-subscription/package-name", checkToken, getSubscriptionPackageByNameFromDB);

module.exports = router