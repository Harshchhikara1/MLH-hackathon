const pool = require('../../config/dbconfig');

module.exports = {
    getUserPhysique: callBack => {
        pool.query(` 
        select * from user_physique`,
            [],
            (error, results, fields) => {
                if (error) {
                    return callBack(error)
                }
                return callBack(null, results)
            })
    },

    getUserPhysiqueByUserId: (user_id, callBack) => {
        pool.query(` 
        select * from user_physique where user_id=?`,
            [user_id],
            (error, results, fields) => {
                if (error) {
                    return callBack(error)
                }
                return callBack(null, results)
            })
    },

    
    addUserPhysique: (data, callBack) =>{
        pool.query('insert into user_physique SET ?', data, (error, results, fields) => {
            if(error){
                return callBack(error)
            }
            return callBack(null, results)
            
            })
        }
    } 
