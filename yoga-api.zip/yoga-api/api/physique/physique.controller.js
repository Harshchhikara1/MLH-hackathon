const { getUserPhysique, getUserPhysiqueByUserId, addUserPhysique } = require('./physique.service')

module.exports = {
    getUserPhysiqueFromDB: (req, res) => {
        getUserPhysique((error, results) => {
            if(error){
                return res.status(404).json({
                    message: "Data not found"
                })
            }
            return res.status(200).json({
                message: "Data Found", results
            })
        })
    },

    getUserPhysiqueByUserIdFromDB: (req, res) => {
        const user_id = req.params.user_id
        getUserPhysiqueByUserId(user_id, (error, results) => {
            if(results.length <= 0){
                return res.status(404).json({
                    message: "Data not found"
                })
            }
            return res.status(200).json({
                message: "Data found", results
            })

        })
    },

    postUserPhysiqueToDB: (req, res) => {
        const data = req.body;        
        addUserPhysique(data, (error, results) => {
            if(error){
                return res.status(400).json({
                    message: "Error found", error
                })
            }
            return res.status(201).json({
                message: "User physique added successfully", results
            })

        })
    }
}