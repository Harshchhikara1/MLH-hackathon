const router = require("express").Router()
const { route } = require("express/lib/router");
const { getUserPhysiqueFromDB, getUserPhysiqueByUserIdFromDB, postUserPhysiqueToDB } = require("./physique.controller")
const { checkToken } = require('../../auth/auth')

router.get("/get-user-physique", checkToken, getUserPhysiqueFromDB);
router.get("/get-user-physique/:user_id", checkToken, getUserPhysiqueByUserIdFromDB);
router.post("/add-user-physique", checkToken, postUserPhysiqueToDB);

module.exports = router