require('dotenv').config()
const express = require('express');
const database = require('./config/dbconfig');
const path = require("path")
const app = express()
const userRouter = require("./api/user/user.routes")
const loginRouter = require("./api/login/login.routes")
const userPhysiqueRouter = require("./api/physique/physique.routes")
const productRouter = require("./api/product/product.routes")
const subscriptionRouter = require("./api/subscription/subscription.routes")
const cartRouter = require("./api/cart/cart.routes")
const orderRouter = require("./api/order/order.routes")

app.use(express.json())
app.use(express.urlencoded())
app.use('/api/user', userRouter)
app.use('/api/login', loginRouter)
app.use('/api/physique', userPhysiqueRouter)
app.use('/api/product', productRouter)
app.use('/api/subscription', subscriptionRouter)
app.use('/api/cart', cartRouter)
app.use('/api/order', orderRouter)

app.listen(process.env.APP_PORT, (req, res) => {
    console.log("Server is running at : ", process.env.APP_PORT);
})