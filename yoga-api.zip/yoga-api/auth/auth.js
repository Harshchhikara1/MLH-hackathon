const { verify } = require('jsonwebtoken');

module.exports = {
    checkToken: (req, res, next) => {
        var token = req.get("authorization");
        if(token){
            token = token.slice(7);
            verify(token, process.env.JWT_KEY, (error, decoded) =>{
                if(error){
                    res.json({
                        message: "Invalid Token"
                    })
                }else{
                    next();
                }
            })
        }else{
            res.json({
                message: "Access denied! Unauthorized user"
            })
        }
    }
}